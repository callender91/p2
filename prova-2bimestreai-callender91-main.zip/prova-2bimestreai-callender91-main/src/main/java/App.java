package main.java;

import java.util.Scanner;

public class App {


    public static void fila(Scanner scanner) {
        //IMPLEMENTE AQUI A LÓGICA PARA A FILA
    }

    public static void lista(Scanner scanner) {
        //IMPLEMENTE AQUI A LÓGICA PARA A LISTA
    }

    public static void main(String[] args) throws Exception {
        //não modifique o método main
        Scanner scanner = new Scanner(System.in);
        fila(scanner);
        lista(scanner);
        scanner.close();
    }
}
